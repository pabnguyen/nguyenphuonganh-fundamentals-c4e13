c = int(input("Enter the temperature in Celsius?"))
f = c * 32
print(c, ("C = "), f, ("F"))
