
r = int(input("Radius = ?"))
A = 3.14 * r * r

print("The area is", A)
