from turtle import *

shape("turtle")

circle(200)

mainloop()
