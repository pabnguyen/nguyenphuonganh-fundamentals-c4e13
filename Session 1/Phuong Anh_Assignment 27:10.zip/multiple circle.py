from turtle import *

shape("turtle")

for c in range(100):
    circle(25)
    left(20)

mainloop()
